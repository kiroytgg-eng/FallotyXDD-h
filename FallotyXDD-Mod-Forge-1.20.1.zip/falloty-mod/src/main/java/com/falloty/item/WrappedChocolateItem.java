package com.falloty.item;

import com.falloty.FallotyRegistry;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Con un click se abre: te da el chocolate y el envoltorio. */
public class WrappedChocolateItem extends Item {
    public WrappedChocolateItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ItemStack bar = new ItemStack(FallotyRegistry.CHOCOLATE_BAR.get());
            ItemStack wrapper = new ItemStack(FallotyRegistry.CHOCOLATE_WRAPPER.get());
            if (!player.getAbilities().instabuild) stack.shrink(1);
            if (!player.getInventory().add(bar)) player.drop(bar, false);
            if (!player.getInventory().add(wrapper)) player.drop(wrapper, false);
            level.playSound(null, player.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0F, 1.3F);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
