package com.falloty.client;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import java.io.ByteArrayInputStream;

/** Lee WAV PCM de 16 bits aunque el encabezado venga con tamano invalido (respuestas en streaming de Fish Audio). */
public class WavDecoder {
    public static AudioInputStream decode(byte[] b) {
        int sampleRate = 24000, channels = 1, bits = 16, dataOff = 0;
        if (b.length > 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F') {
            int p = 12;
            boolean foundData = false;
            while (p + 8 <= b.length) {
                String id = new String(b, p, 4, java.nio.charset.StandardCharsets.US_ASCII);
                long size = le32(b, p + 4);
                if (id.equals("fmt ") && p + 24 <= b.length) {
                    channels = le16(b, p + 10);
                    sampleRate = (int) le32(b, p + 12);
                    bits = le16(b, p + 22);
                } else if (id.equals("data")) {
                    dataOff = p + 8; foundData = true; break;
                }
                long next = p + 8L + size + (size & 1);
                if (size < 0 || next > b.length || next <= p) break;
                p = (int) next;
            }
            if (!foundData) dataOff = Math.min(44, b.length);
        }
        if (channels < 1 || channels > 2) channels = 1;
        if (bits != 16) bits = 16;
        if (sampleRate < 4000 || sampleRate > 96000) sampleRate = 24000;
        int frame = channels * 2;
        int len = (b.length - dataOff) / frame * frame;
        if (len <= 0) return null;
        AudioFormat fmt = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, sampleRate, 16, channels, frame, sampleRate, false);
        return new AudioInputStream(new ByteArrayInputStream(b, dataOff, len), fmt, len / frame);
    }

    private static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
    private static long le32(byte[] b, int o) { return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24); }
}
