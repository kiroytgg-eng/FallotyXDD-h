package com.falloty.client;

import com.falloty.net.AudioChunkPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import org.apache.logging.log4j.LogManager;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Reune los trozos WAV que manda el servidor y reproduce la voz de FallotyXDD. */
public class ClientAudio {
    private static final Map<Integer, byte[][]> PARTS = new HashMap<>();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "falloty-audio"); t.setDaemon(true); return t;
    });

    public static void receive(AudioChunkPacket p) {
        if (PARTS.size() > 16) PARTS.clear();
        byte[][] arr = PARTS.computeIfAbsent(p.messageId, k -> new byte[p.total][]);
        if (p.index < 0 || p.index >= arr.length) return;
        arr[p.index] = p.data;
        for (byte[] b : arr) if (b == null) return;
        PARTS.remove(p.messageId);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        for (byte[] b : arr) bos.write(b, 0, b.length);
        byte[] wav = bos.toByteArray();

        Minecraft mc = Minecraft.getInstance();
        float dist = 6F;
        if (mc.level != null && mc.player != null) {
            Entity ent = mc.level.getEntity(p.entityId);
            if (ent != null) dist = ent.distanceTo(mc.player);
        }
        float att = Math.max(0F, Math.min(1F, 1F - dist / 40F));
        float vol = mc.options.getSoundSourceVolume(SoundSource.MASTER) * mc.options.getSoundSourceVolume(SoundSource.VOICE) * att;
        if (vol < 0.01F) return;
        final float fv = vol;
        EXEC.execute(() -> play(wav, fv));
    }

    private static void play(byte[] wav, float vol) {
        try (AudioInputStream in = WavDecoder.decode(wav)) {
            if (in == null) { LogManager.getLogger("falloty").warn("Audio vacio recibido"); return; }
            Clip clip = AudioSystem.getClip();
            clip.open(in);
            if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gc = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                float db = (float) (20.0 * Math.log10(Math.max(vol, 0.0001F)));
                gc.setValue(Math.max(gc.getMinimum(), Math.min(gc.getMaximum(), db)));
            }
            clip.addLineListener(ev -> { if (ev.getType() == LineEvent.Type.STOP) clip.close(); });
            clip.start();
        } catch (Exception e) {
            LogManager.getLogger("falloty").warn("No se pudo reproducir la voz: " + e);
        }
    }
}
