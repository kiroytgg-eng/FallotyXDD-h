package com.falloty.net;

import com.falloty.client.ClientAudio;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Trozo de audio WAV (voz de FallotyXDD) enviado del servidor al cliente. */
public class AudioChunkPacket {
    public final int entityId, messageId, index, total;
    public final byte[] data;

    public AudioChunkPacket(int entityId, int messageId, int index, int total, byte[] data) {
        this.entityId = entityId; this.messageId = messageId; this.index = index; this.total = total; this.data = data;
    }

    public static void encode(AudioChunkPacket p, FriendlyByteBuf b) {
        b.writeInt(p.entityId); b.writeInt(p.messageId); b.writeInt(p.index); b.writeInt(p.total);
        b.writeByteArray(p.data);
    }

    public static AudioChunkPacket decode(FriendlyByteBuf b) {
        int e = b.readInt(), m = b.readInt(), i = b.readInt(), t = b.readInt();
        return new AudioChunkPacket(e, m, i, t, b.readByteArray());
    }

    public static void handle(AudioChunkPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientAudio.receive(p)));
        ctx.get().setPacketHandled(true);
    }
}
