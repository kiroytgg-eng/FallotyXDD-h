package com.falloty.net;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

public class FallotyNetwork {
    private static final String VERSION = "1";
    private static final AtomicInteger MSG = new AtomicInteger();
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation("falloty", "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0, AudioChunkPacket.class, AudioChunkPacket::encode, AudioChunkPacket::decode,
                AudioChunkPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    /** Envia el WAV en trozos pequenos a los jugadores cercanos. */
    public static void sendVoice(Entity speaker, byte[] wav) {
        if (!(speaker.level() instanceof ServerLevel level)) return;
        final int chunk = 24000;
        int total = (wav.length + chunk - 1) / chunk;
        int id = MSG.incrementAndGet();
        for (int i = 0; i < total; i++) {
            byte[] part = Arrays.copyOfRange(wav, i * chunk, Math.min(wav.length, (i + 1) * chunk));
            CHANNEL.send(PacketDistributor.NEAR.with(() ->
                    new PacketDistributor.TargetPoint(speaker.getX(), speaker.getY(), speaker.getZ(), 64, level.dimension())),
                    new AudioChunkPacket(speaker.getId(), id, i, total, part));
        }
    }
}
