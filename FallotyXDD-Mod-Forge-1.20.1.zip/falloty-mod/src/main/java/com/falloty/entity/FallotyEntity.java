package com.falloty.entity;

import com.falloty.FallotyRegistry;
import com.falloty.ai.FriendBrain;
import com.falloty.event.ServerEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

public class FallotyEntity extends PathfinderMob {
    public enum Mode { FOLLOW, STAY, MINE, CHOP, BUILD, SLEEP }

    private static final EntityDataAccessor<Integer> DATA_MODE = SynchedEntityData.defineId(FallotyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_SITTING = SynchedEntityData.defineId(FallotyEntity.class, EntityDataSerializers.BOOLEAN);

    public final SimpleContainer inventory = new SimpleContainer(27);
    public final FriendBrain brain = new FriendBrain(this);

    private UUID ownerUUID;
    private BlockPos home;
    public int sessionStart, minedCount, choppedCount;
    public boolean shareLoot;

    // picar bloques
    private BlockPos breakingPos;
    private int breakProgress, breakTotal;

    // animacion (solo cliente)
    public float animDist, animDistO, moveBlend, moveBlendO, runBlend, runBlendO, airBlend, airBlendO, speedSmooth, sitBlend, sitBlendO;

    private final ItemStack pickaxe = tool(Items.DIAMOND_PICKAXE);
    private final ItemStack axe = tool(Items.IRON_AXE);
    private final ItemStack sword = tool(Items.IRON_SWORD);

    public FallotyEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("FallotyXDD"));
        this.setCustomNameVisible(true);
        this.setPersistenceRequired();
        this.xpReward = 0;
        if (getNavigation() instanceof GroundPathNavigation g) { g.setCanOpenDoors(true); g.setCanFloat(true); }
    }

    private static ItemStack tool(Item i) {
        ItemStack s = new ItemStack(i);
        s.getOrCreateTag().putBoolean("Unbreakable", true);
        return s;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_MODE, 0);
        this.entityData.define(DATA_SITTING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(1, new FallotyGoals.EatChocolateGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, true) {
            @Override public boolean canUse() { return !isSitting() && super.canUse(); }
            @Override public boolean canContinueToUse() { return !isSitting() && super.canContinueToUse(); }
        });
        this.goalSelector.addGoal(3, new FallotyGoals.SleepInBedGoal(this));
        this.goalSelector.addGoal(4, new FallotyGoals.BuildHouseGoal(this));
        this.goalSelector.addGoal(5, new FallotyGoals.ChopTreeGoal(this));
        this.goalSelector.addGoal(5, new FallotyGoals.MineOreGoal(this));
        this.goalSelector.addGoal(6, new FallotyGoals.FollowOwnerGoal(this));
        this.goalSelector.addGoal(7, new TemptGoal(this, 1.1D,
                Ingredient.of(FallotyRegistry.CHOCOLATE_WRAPPED.get(), FallotyRegistry.CHOCOLATE_BAR.get()), false) {
            @Override public boolean canUse() { return getMode() == Mode.FOLLOW && !isSitting() && super.canUse(); }
        });
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new FallotyGoals.DefendOwnerGoal(this));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Monster.class, 5, true, false,
                m -> !isSitting() && !isSleeping() && getOwner() != null && m.distanceToSqr(getOwner()) < 20 * 20));
    }

    /* ---------- datos ---------- */
    public Mode getMode() { return Mode.values()[Mth.clamp(entityData.get(DATA_MODE), 0, Mode.values().length - 1)]; }
    public boolean isSitting() { return entityData.get(DATA_SITTING); }
    public void setSitting(boolean b) { entityData.set(DATA_SITTING, b); if (b) getNavigation().stop(); }
    @Nullable public UUID getOwnerUUID() { return ownerUUID; }
    public void setOwner(UUID id) { this.ownerUUID = id; }
    @Nullable public Player getOwner() { return ownerUUID == null ? null : level().getPlayerByUUID(ownerUUID); }
    @Nullable public BlockPos getHome() { return home; }
    public void setHome(BlockPos p) { home = p; }

    public void setMode(Mode m) {
        if (isSleeping() && m != Mode.SLEEP) stopSleeping();
        if (m != Mode.STAY) setSitting(false);
        entityData.set(DATA_MODE, m.ordinal());
        getNavigation().stop();
        resetBreak();
        sessionStart = tickCount;
        minedCount = 0; choppedCount = 0;
        refreshTool();
    }

    public void giveStarterKit() {
        setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
        setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
        setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
        for (EquipmentSlot s : EquipmentSlot.values()) setDropChance(s, 0F);
        inventory.addItem(new ItemStack(FallotyRegistry.CHOCOLATE_WRAPPED.get(), 3));
        inventory.addItem(new ItemStack(Items.BREAD, 8));
    }

    public void refreshTool() {
        if (isUsingItem()) return;
        ItemStack want = switch (getMode()) {
            case MINE -> getTarget() != null ? sword : pickaxe;
            case CHOP -> getTarget() != null ? sword : axe;
            default -> getTarget() != null ? sword : ItemStack.EMPTY;
        };
        if (!ItemStack.isSameItem(getMainHandItem(), want)) setItemSlot(EquipmentSlot.MAINHAND, want.copy());
    }

    /* ---------- tick ---------- */
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) { clientAnimTick(); return; }
        if (tickCount % 10 == 0) refreshTool();
        if (tickCount % 80 == 0 && getHealth() < getMaxHealth()) heal(1.0F);

        // dormir / despertar
        if (isSleeping()) {
            Player o = getOwner();
            boolean ownerSleeping = o != null && o.isSleeping();
            if (getMode() == Mode.SLEEP && level().isDay() && !ownerSleeping) setMode(Mode.FOLLOW);
            else if (getMode() != Mode.SLEEP && !ownerSleeping) stopSleeping();
        } else if (getMode() == Mode.SLEEP && tickCount - sessionStart > 900) {
            setMode(Mode.FOLLOW);
            brain.onEvent("no encontraste una cama libre cerca para dormir");
        }

        // correr si va lejos del jugador o persigue a alguien
        boolean run = false;
        LivingEntity t = getTarget();
        Player o = getOwner();
        if (t != null && t.isAlive()) run = distanceToSqr(t) > 9;
        else if (getMode() == Mode.FOLLOW && !isSitting() && o != null) run = distanceToSqr(o) > 100;
        setSprinting(run && !getNavigation().isDone());

        // no quedarse muy lejos del jugador
        if (o != null && !isSleeping() && getMode() != Mode.BUILD && !isSitting() && getMode() != Mode.STAY) {
            double d = distanceToSqr(o);
            if (d > 48 * 48 || (getMode() == Mode.FOLLOW && d > 28 * 28)) teleportToOwner();
        }
        // entregar lo recogido
        if (shareLoot && getMode() == Mode.FOLLOW && o != null && distanceToSqr(o) < 25) {
            int n = dumpInventoryTo(o);
            shareLoot = false;
            if (n > 0) brain.onEvent("le entregaste al jugador " + n + " items que recogiste");
        }
    }

    public void teleportToOwner() {
        Player o = getOwner();
        if (o == null) return;
        for (int i = 0; i < 12; i++) {
            double x = o.getX() + (random.nextDouble() - 0.5) * 6;
            double z = o.getZ() + (random.nextDouble() - 0.5) * 6;
            double y = o.getY();
            AABB box = getBoundingBox().move(x - getX(), y - getY(), z - getZ());
            if (level().noCollision(this, box)) {
                moveTo(x, y, z, getYRot(), getXRot());
                getNavigation().stop();
                return;
            }
        }
        moveTo(o.getX(), o.getY(), o.getZ());
        getNavigation().stop();
    }

    @Override public boolean isImmobile() { return super.isImmobile() || isSleeping() || isSitting(); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return !isSleeping() && super.isPushable(); }

    /* ---------- acciones (las manda el cerebro de Groq o los comandos) ---------- */
    public void performAction(String action, @Nullable Player from) {
        switch (action) {
            case "follow", "stop" -> setMode(Mode.FOLLOW);
            case "come" -> { setMode(Mode.FOLLOW); if (from != null) getNavigation().moveTo(from, 1.3D); }
            case "stay" -> setMode(Mode.STAY);
            case "mine" -> setMode(Mode.MINE);
            case "chop" -> setMode(Mode.CHOP);
            case "build_house" -> setMode(Mode.BUILD);
            case "sleep" -> setMode(Mode.SLEEP);
            case "wake" -> setMode(Mode.FOLLOW);
            case "sit" -> { if (getMode() == Mode.SLEEP || getMode() == Mode.MINE || getMode() == Mode.CHOP || getMode() == Mode.BUILD) setMode(Mode.FOLLOW); setSitting(true); }
            case "stand" -> setSitting(false);
            case "attack" -> {
                setSitting(false);
                List<Monster> list = level().getEntitiesOfClass(Monster.class, getBoundingBox().inflate(16));
                list.stream().min((a, b) -> Double.compare(a.distanceToSqr(this), b.distanceToSqr(this))).ifPresent(this::setTarget);
            }
            case "give_items" -> { if (from != null) dumpInventoryTo(from); }
            default -> { }
        }
    }

    public void finishSession(String eventText) {
        boolean loot = false;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty() && !FallotyRegistry.isChocolate(s) && !s.is(Items.BREAD)) { loot = true; break; }
        }
        shareLoot = loot;
        setMode(Mode.FOLLOW);
        brain.onEvent(eventText);
    }

    public int dumpInventoryTo(Player p) {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty() || FallotyRegistry.isChocolate(s) || s.is(Items.BREAD)) continue;
            ItemStack copy = s.copy();
            inventory.setItem(i, ItemStack.EMPTY);
            n += copy.getCount();
            if (!p.getInventory().add(copy)) p.drop(copy, false);
        }
        if (n > 0) level().playSound(null, p.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.6F, 1.0F);
        return n;
    }

    public boolean hasChocolate() {
        for (int i = 0; i < inventory.getContainerSize(); i++) if (FallotyRegistry.isChocolate(inventory.getItem(i))) return true;
        return false;
    }

    public ItemStack takeChocolateBar() {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(FallotyRegistry.CHOCOLATE_BAR.get())) return s.split(1);
        }
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(FallotyRegistry.CHOCOLATE_WRAPPED.get())) {
                s.shrink(1);
                inventory.addItem(new ItemStack(FallotyRegistry.CHOCOLATE_WRAPPER.get()));
                return new ItemStack(FallotyRegistry.CHOCOLATE_BAR.get());
            }
        }
        return ItemStack.EMPTY;
    }

    /* ---------- dormir ---------- */
    @Nullable
    public BlockPos findFreeBed(int r) {
        BlockPos c = blockPosition();
        BlockPos best = null; double bd = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -4, -r), c.offset(r, 4, r))) {
            BlockState st = level().getBlockState(p);
            if (!st.is(BlockTags.BEDS) || !st.hasProperty(BedBlock.PART)) continue;
            if (st.getValue(BedBlock.PART) != BedPart.HEAD || st.getValue(BedBlock.OCCUPIED)) continue;
            double d = p.distSqr(c);
            if (d < bd) { bd = d; best = p.immutable(); }
        }
        return best;
    }

    public void trySleep(BlockPos head) {
        BlockState st = level().getBlockState(head);
        if (!st.is(BlockTags.BEDS)) return;
        Direction facing = st.getValue(BedBlock.FACING);
        getNavigation().stop();
        startSleeping(head);
        Vec3 c = Vec3.atBottomCenterOf(head).relative(facing.getOpposite(), 0.5D).add(0, 0.5625D, 0);
        setPos(c.x, c.y, c.z);
        setDeltaMovement(Vec3.ZERO);
    }

    /* ---------- picar bloques ---------- */
    public void resetBreak() {
        if (breakingPos != null && level() instanceof ServerLevel sl) sl.destroyBlockProgress(getId(), breakingPos, -1);
        breakingPos = null; breakProgress = 0;
    }

    public boolean safeToBreak(BlockPos pos, boolean allowAnyNatural) {
        BlockState st = level().getBlockState(pos);
        if (st.getDestroySpeed(level(), pos) < 0) return false;
        if (!allowAnyNatural && !isNatural(st)) return false;
        for (Direction d : Direction.values()) {
            if (level().getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return false;
        }
        return !level().getFluidState(pos.below(2)).is(FluidTags.LAVA);
    }

    public static boolean isNatural(BlockState s) {
        return s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.BASE_STONE_NETHER) || s.is(BlockTags.DIRT)
                || s.is(BlockTags.SAND) || s.is(Tags.Blocks.ORES) || s.is(Blocks.GRAVEL) || s.is(BlockTags.LEAVES)
                || s.is(BlockTags.SNOW) || s.is(Blocks.SANDSTONE) || s.is(Blocks.CLAY) || s.is(Blocks.CALCITE)
                || s.is(Blocks.DRIPSTONE_BLOCK) || s.is(Blocks.SMOOTH_BASALT) || s.is(Blocks.BASALT) || s.is(Blocks.BLACKSTONE);
    }

    /** Avanza 1 tick picando el bloque. true = ya se rompio (o no hay nada que romper). */
    public boolean breakBlockStep(BlockPos pos) {
        if (!(level() instanceof ServerLevel sl)) return true;
        BlockState st = sl.getBlockState(pos);
        if (st.isAir() || st.getDestroySpeed(sl, pos) < 0) { resetBreak(); return true; }
        if (!pos.equals(breakingPos)) {
            resetBreak();
            breakingPos = pos.immutable();
            breakProgress = 0;
            ItemStack tool = getMainHandItem();
            float hardness = st.getDestroySpeed(sl, pos);
            float speed = Math.max(1.0F, tool.getDestroySpeed(st));
            boolean correct = !st.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(st);
            breakTotal = Math.max(4, (int) Math.ceil(hardness * (correct ? 30.0F : 100.0F) / speed * 0.6F));
        }
        getLookControl().setLookAt(Vec3.atCenterOf(pos));
        if (breakProgress % 6 == 0) swing(InteractionHand.MAIN_HAND);
        breakProgress++;
        sl.destroyBlockProgress(getId(), pos, Math.min(9, (int) (10.0F * breakProgress / breakTotal)));
        if (breakProgress % 4 == 0) sl.playSound(null, pos, st.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.7F, 0.8F);
        if (breakProgress >= breakTotal) {
            collectDrops(sl, pos, st);
            sl.destroyBlock(pos, false, this);
            resetBreak();
            return true;
        }
        return false;
    }

    public void collectDrops(ServerLevel sl, BlockPos pos, BlockState st) {
        BlockEntity be = sl.getBlockEntity(pos);
        for (ItemStack d : Block.getDrops(st, sl, pos, be, this, getMainHandItem())) {
            ItemStack rest = inventory.addItem(d);
            if (!rest.isEmpty()) spawnAtLocation(rest);
        }
    }

    /* ---------- interaccion ---------- */
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        boolean client = level().isClientSide;
        if (FallotyRegistry.isChocolate(held)) {
            if (!client) {
                ItemStack one = held.copy(); one.setCount(1);
                if (!player.getAbilities().instabuild) held.shrink(1);
                inventory.addItem(one);
                heal(4.0F);
                ((ServerLevel) level()).sendParticles(ParticleTypes.HEART, getX(), getY() + 1.9, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
                playSound(SoundEvents.PLAYER_BURP, 0.6F, 1.4F);
                brain.onEvent(player.getGameProfile().getName() + " te regalo un chocolate, ¡te encanta el chocolate!");
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (ownerUUID != null && !player.getUUID().equals(ownerUUID)) return InteractionResult.PASS;
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (player.isShiftKeyDown()) {
            if (!client) {
                int n = dumpInventoryTo(player);
                if (n == 0) brain.onEvent("no tienes nada que darle al jugador ahora mismo");
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (held.isEmpty()) {
            if (!client) {
                if (getMode() != Mode.FOLLOW && getMode() != Mode.STAY) setMode(Mode.FOLLOW);
                setSitting(!isSitting());
            }
            return InteractionResult.sidedSuccess(client);
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (src.getEntity() instanceof Player p && p.getUUID().equals(ownerUUID)) return false;
        boolean r = super.hurt(src, amount);
        if (r && !level().isClientSide) {
            if (isSleeping()) stopSleeping();
            if (random.nextInt(4) == 0) brain.onEvent("te hicieron daño, te queda " + (int) getHealth() + " de vida");
        }
        return r;
    }

    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (!level().isClientSide) {
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                ItemStack s = inventory.getItem(i);
                if (!s.isEmpty()) spawnAtLocation(s);
            }
            inventory.clearContent();
            ServerEvents.onFriendDied(this);
        }
    }

    /* ---------- guardado ---------- */
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUUID != null) tag.putUUID("FOwner", ownerUUID);
        tag.putInt("FMode", getMode().ordinal());
        tag.putBoolean("FSit", isSitting());
        if (home != null) tag.putLong("FHome", home.asLong());
        tag.put("FInv", inventory.createTag());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("FOwner")) ownerUUID = tag.getUUID("FOwner");
        entityData.set(DATA_MODE, Mth.clamp(tag.getInt("FMode"), 0, Mode.values().length - 1));
        entityData.set(DATA_SITTING, tag.getBoolean("FSit"));
        if (tag.contains("FHome")) home = BlockPos.of(tag.getLong("FHome"));
        if (tag.contains("FInv")) inventory.fromTag(tag.getList("FInv", 10));
    }

    /* ---------- animacion cliente ---------- */
    private void clientAnimTick() {
        sitBlendO = sitBlend; animDistO = animDist; moveBlendO = moveBlend; runBlendO = runBlend; airBlendO = airBlend;
        double dx = getX() - xo, dz = getZ() - zo;
        float sp = (float) Math.sqrt(dx * dx + dz * dz);
        speedSmooth += (sp - speedSmooth) * 0.35F;
        animDist += sp;
        moveBlend += ((speedSmooth > 0.03F ? 1F : 0F) - moveBlend) * 0.3F;
        runBlend += ((isSprinting() ? 1F : 0F) - runBlend) * 0.2F;
        sitBlend += ((isSitting() && !isSleeping() ? 1F : 0F) - sitBlend) * 0.25F;
        airBlend += ((!onGround() && !isInWater() && !isSleeping() ? 1F : 0F) - airBlend) * 0.35F;
    }
}
