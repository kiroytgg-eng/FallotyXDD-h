package com.falloty.event;

import com.falloty.FallotyConfig;
import com.falloty.FallotyRegistry;
import com.falloty.ai.FriendBrain;
import com.falloty.entity.FallotyEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.*;

public class ServerEvents {
    private static final String SAVED = "FallotyData";
    private static class Pending { int ticks; boolean announce; Pending(int t, boolean a) { ticks = t; announce = a; } }
    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Set<UUID> WAITING_KEY = new HashSet<>();
    private static final Map<UUID, FallotyEntity> FRIENDS = new HashMap<>();

    /* ---------- utilidades ---------- */
    private static CompoundTag persisted(Player p) {
        CompoundTag d = p.getPersistentData();
        if (!d.contains(Player.PERSISTED_NBT_TAG)) d.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        return d.getCompound(Player.PERSISTED_NBT_TAG);
    }

    public static FallotyEntity findFriend(MinecraftServer s, UUID owner) {
        FallotyEntity c = FRIENDS.get(owner);
        if (c != null && c.isAlive() && !c.isRemoved()) return c;
        for (ServerLevel l : s.getAllLevels())
            for (Entity en : l.getAllEntities())
                if (en instanceof FallotyEntity f && owner.equals(f.getOwnerUUID()) && f.isAlive()) { FRIENDS.put(owner, f); return f; }
        FRIENDS.remove(owner);
        return null;
    }

    private static void schedule(UUID id, int ticks, boolean announce) { PENDING.put(id, new Pending(ticks, announce)); }

    /* ---------- entrar / salir ---------- */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        schedule(sp.getUUID(), FallotyConfig.JOIN_DELAY_SECONDS.get() * 20, true);
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        PENDING.remove(sp.getUUID()); WAITING_KEY.remove(sp.getUUID());
        if (despawn(sp)) FriendBrain.yellow(sp.server, "FallotyXDD salió de la partida");
    }

    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (despawn(sp)) schedule(sp.getUUID(), 30, false);
    }

    /** Guarda al amigo (inventario, modo, casa) en los datos del jugador y lo quita del mundo. */
    private static boolean despawn(ServerPlayer sp) {
        FallotyEntity f = findFriend(sp.server, sp.getUUID());
        if (f == null) return false;
        CompoundTag tag = new CompoundTag();
        f.saveWithoutId(tag);
        persisted(sp).put(SAVED, tag);
        f.discard();
        FRIENDS.remove(sp.getUUID());
        return true;
    }

    private static void spawnFriend(ServerPlayer sp, boolean announce) {
        MinecraftServer s = sp.server;
        if (!FallotyConfig.hasGroq()) {
            WAITING_KEY.add(sp.getUUID());
            sp.sendSystemMessage(Component.literal("[FallotyXDD] No puedo unirme: falta la API key de Groq.").withStyle(ChatFormatting.RED));
            sp.sendSystemMessage(Component.literal("Ponla con /falloty groqkey <tu_key>  (o en config/falloty-common.toml). Para la voz: /falloty fishkey <tu_key>").withStyle(ChatFormatting.GOLD));
            return;
        }
        if (!FallotyConfig.hasFish())
            sp.sendSystemMessage(Component.literal("[FallotyXDD] Sin API key de Fish Audio solo hablara por chat (sin voz): /falloty fishkey <key>").withStyle(ChatFormatting.GRAY));
        ServerLevel lv = sp.serverLevel();
        FallotyEntity existing = findFriend(s, sp.getUUID());
        if (existing != null) {
            if (existing.level() == lv) { existing.teleportToOwner(); return; }
            despawn(sp);
        }
        CompoundTag saved = persisted(sp).contains(SAVED) ? persisted(sp).getCompound(SAVED).copy() : null;
        FallotyEntity f = FallotyRegistry.FALLOTY.get().create(lv);
        if (f == null) return;
        if (saved != null) {
            saved.remove("SleepingPos"); saved.remove("Passengers");
            f.load(saved);
        } else {
            f.giveStarterKit();
        }
        f.setOwner(sp.getUUID());
        f.setMode(FallotyEntity.Mode.FOLLOW);
        Random r = new Random();
        boolean placed = false;
        for (int i = 0; i < 16 && !placed; i++) {
            double ang = r.nextDouble() * Math.PI * 2, d = 2.5 + r.nextDouble() * 2;
            double x = sp.getX() + Math.cos(ang) * d, z = sp.getZ() + Math.sin(ang) * d, y = sp.getY();
            f.moveTo(x, y, z, sp.getYRot() + 180F, 0F);
            if (lv.noCollision(f)) placed = true;
        }
        if (!placed) f.moveTo(sp.getX(), sp.getY(), sp.getZ(), sp.getYRot(), 0F);
        lv.addFreshEntity(f);
        FRIENDS.put(sp.getUUID(), f);
        if (announce) FriendBrain.yellow(s, "FallotyXDD se unió a la partida");
        f.brain.onEvent(saved == null ? "acabas de unirte a la partida de tu amigo " + sp.getGameProfile().getName() : "volviste a unirte a la partida de tu amigo " + sp.getGameProfile().getName());
    }

    public static void onFriendDied(FallotyEntity f) {
        UUID owner = f.getOwnerUUID();
        MinecraftServer s = f.getServer();
        if (owner == null || s == null) return;
        FRIENDS.remove(owner);
        FriendBrain.yellow(s, "FallotyXDD murió");
        ServerPlayer sp = s.getPlayerList().getPlayer(owner);
        if (sp != null) {
            persisted(sp).remove(SAVED);
            schedule(owner, 20 * 20, true); // reaparece a los 20 segundos
        }
    }

    /* ---------- tick ---------- */
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || PENDING.isEmpty()) return;
        List<UUID> due = new ArrayList<>();
        for (Map.Entry<UUID, Pending> en : PENDING.entrySet()) if (--en.getValue().ticks <= 0) due.add(en.getKey());
        for (UUID id : due) {
            Pending p = PENDING.remove(id);
            ServerPlayer sp = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer().getPlayerList().getPlayer(id);
            if (sp != null && p != null) spawnFriend(sp, p.announce);
        }
    }

    /* ---------- chat ---------- */
    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        ServerPlayer sp = e.getPlayer();
        String msg = e.getRawText();
        String low = msg.toLowerCase(Locale.ROOT);
        boolean named = low.contains("falloty") || low.contains("fallo");
        FallotyEntity f = findFriend(sp.server, sp.getUUID());
        boolean own = f != null;
        if (!own && named) {
            double best = 64 * 64;
            for (FallotyEntity c : FRIENDS.values()) {
                if (!c.isAlive() || c.level() != sp.level()) continue;
                double d = c.distanceToSqr(sp);
                if (d < best) { best = d; f = c; }
            }
        }
        if (f == null) return;
        boolean close = own && f.level() == sp.level() && f.distanceToSqr(sp) <= 32 * 32;
        if (named || (own && close && FallotyConfig.ANSWER_ALL_CHAT.get())) f.brain.onPlayerMessage(sp, msg);
    }

    /* ---------- comandos ---------- */
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("falloty")
                .requires(s -> s.hasPermission(2) || s.getServer().isSingleplayer())
                .then(Commands.literal("groqkey").then(Commands.argument("key", StringArgumentType.string()).executes(c -> {
                    FallotyConfig.GROQ_KEY.set(StringArgumentType.getString(c, "key").trim());
                    FallotyConfig.GROQ_KEY.save();
                    c.getSource().sendSuccess(() -> Component.literal("API key de Groq guardada."), false);
                    for (UUID id : new ArrayList<>(WAITING_KEY)) { WAITING_KEY.remove(id); schedule(id, FallotyConfig.JOIN_DELAY_SECONDS.get() * 20, true); }
                    return 1;
                })))
                .then(Commands.literal("fishkey").then(Commands.argument("key", StringArgumentType.string()).executes(c -> {
                    FallotyConfig.FISH_KEY.set(StringArgumentType.getString(c, "key").trim());
                    FallotyConfig.FISH_KEY.save();
                    c.getSource().sendSuccess(() -> Component.literal("API key de Fish Audio guardada (ya tiene voz)."), false);
                    return 1;
                })))
                .then(Commands.literal("voice").then(Commands.argument("id", StringArgumentType.string()).executes(c -> {
                    FallotyConfig.FISH_VOICE_ID.set(StringArgumentType.getString(c, "id").trim());
                    FallotyConfig.FISH_VOICE_ID.save();
                    c.getSource().sendSuccess(() -> Component.literal("Voz de Fish Audio guardada."), false);
                    return 1;
                })))
                .then(Commands.literal("test").then(Commands.argument("texto", StringArgumentType.greedyString()).executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    FallotyEntity f = findFriend(sp.server, sp.getUUID());
                    if (f == null) { c.getSource().sendFailure(Component.literal("FallotyXDD no esta en la partida. Usa /falloty spawn")); return 0; }
                    c.getSource().sendSuccess(() -> Component.literal("Enviando a Groq..."), false);
                    f.brain.test(sp, StringArgumentType.getString(c, "texto"));
                    return 1;
                })))
                .then(Commands.literal("voicetest").then(Commands.argument("texto", StringArgumentType.greedyString()).executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    if (!FallotyConfig.hasFish()) { c.getSource().sendFailure(Component.literal("Falta la API key de Fish Audio: /falloty fishkey <key>")); return 0; }
                    final String txt = StringArgumentType.getString(c, "texto");
                    final String k = FallotyConfig.FISH_KEY.get(), m = FallotyConfig.FISH_MODEL.get(), v = FallotyConfig.FISH_VOICE_ID.get();
                    c.getSource().sendSuccess(() -> Component.literal("Generando voz con Fish Audio..."), false);
                    java.util.concurrent.CompletableFuture.supplyAsync(() -> com.falloty.ai.Http.fishTts(k, m, v, txt), com.falloty.ai.Http.POOL).thenAccept(wav ->
                        sp.server.execute(() -> {
                            if (wav == null) { sp.sendSystemMessage(Component.literal("[FallotyXDD] Error de Fish Audio: " + com.falloty.ai.Http.lastFishError).withStyle(ChatFormatting.RED)); return; }
                            FallotyEntity f = findFriend(sp.server, sp.getUUID());
                            com.falloty.net.FallotyNetwork.sendVoice(f != null ? f : sp, wav);
                            sp.sendSystemMessage(Component.literal("[FallotyXDD] Voz enviada (" + wav.length / 1024 + " KB). Si no la oyes, revisa el volumen de 'Voces' en Opciones > Sonido.").withStyle(ChatFormatting.GRAY));
                        }));
                    return 1;
                })))
                .then(Commands.literal("spawn").executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    schedule(sp.getUUID(), 20, true);
                    return 1;
                }))
                .then(Commands.literal("status").executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    FallotyEntity f = findFriend(sp.server, sp.getUUID());
                    String txt = "Groq: " + (FallotyConfig.hasGroq() ? "OK" : "FALTA key") + " | Fish Audio: " + (FallotyConfig.hasFish() ? "OK" : "sin key (sin voz)")
                            + " | Amigo: " + (f != null ? "presente, modo " + f.getMode() : "no esta");
                    c.getSource().sendSuccess(() -> Component.literal(txt), false);
                    return 1;
                })));
    }
}
