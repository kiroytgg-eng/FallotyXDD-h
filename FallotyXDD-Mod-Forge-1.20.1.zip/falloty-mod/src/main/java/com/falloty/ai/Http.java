package com.falloty.ai;

import com.falloty.FallotyMod;
import com.google.gson.*;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Llamadas HTTP a Groq (cerebro) y Fish Audio (voz). Se ejecutan fuera del hilo del servidor. */
public class Http {
    public static final ExecutorService POOL = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "falloty-http"); t.setDaemon(true); return t;
    });
    private static final Gson GSON = new Gson();
    private static final String UA = "FallotyXDD-MinecraftMod/1.0 (Java)";
    public static volatile String lastFishError = null;

    private static class Res { int code; byte[] data; }

    private static Res post(String url, Map<String, String> headers, String json, int readTimeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(10000);
        c.setReadTimeout(readTimeoutMs);
        c.setDoOutput(true);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Content-Type", "application/json");
        for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
        try (OutputStream o = c.getOutputStream()) { o.write(json.getBytes(StandardCharsets.UTF_8)); }
        Res r = new Res();
        r.code = c.getResponseCode();
        InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
        r.data = in == null ? new byte[0] : in.readAllBytes();
        return r;
    }

    private static String shorten(String s) { return s.length() > 220 ? s.substring(0, 220) + "..." : s; }

    /** Devuelve el JSON que contesta Groq, o un texto que empieza por "ERR:" si algo falla. */
    public static String groqChat(String key, String model, List<String[]> messages) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("model", model);
            body.addProperty("temperature", 0.8);
            body.addProperty("max_tokens", 350);
            JsonObject fmt = new JsonObject(); fmt.addProperty("type", "json_object");
            body.add("response_format", fmt);
            JsonArray arr = new JsonArray();
            for (String[] m : messages) {
                JsonObject o = new JsonObject(); o.addProperty("role", m[0]); o.addProperty("content", m[1]); arr.add(o);
            }
            body.add("messages", arr);
            Res res = post("https://api.groq.com/openai/v1/chat/completions",
                    Map.of("Authorization", "Bearer " + key), GSON.toJson(body), 30000);
            String text = new String(res.data, StandardCharsets.UTF_8);
            if (res.code != 200) {
                log("Groq HTTP " + res.code + ": " + text);
                return "ERR:HTTP " + res.code + " " + shorten(text);
            }
            JsonObject json = JsonParser.parseString(text).getAsJsonObject();
            return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString();
        } catch (Exception e) {
            log("Groq error: " + e);
            return "ERR:" + e;
        }
    }

    /** Devuelve bytes WAV o null (el motivo queda en lastFishError). */
    public static byte[] fishTts(String key, String model, String voiceId, String text) {
        lastFishError = null;
        try {
            JsonObject body = new JsonObject();
            body.addProperty("text", text);
            if (voiceId != null && !voiceId.isBlank()) body.addProperty("reference_id", voiceId.trim());
            body.addProperty("format", "wav");
            body.addProperty("sample_rate", 24000);
            body.addProperty("normalize", true);
            Res res = post("https://api.fish.audio/v1/tts",
                    Map.of("Authorization", "Bearer " + key, "model", model), GSON.toJson(body), 40000);
            if ((res.code == 402 || res.code == 403) && !model.equals("s2.1-pro-free")) { // cuenta gratis: reintenta con el modelo gratuito
                res = post("https://api.fish.audio/v1/tts",
                        Map.of("Authorization", "Bearer " + key, "model", "s2.1-pro-free"), GSON.toJson(body), 40000);
            }
            if (res.code == 200 && res.data.length < 200) {
                lastFishError = "Fish devolvio audio vacio: " + shorten(new String(res.data, StandardCharsets.UTF_8));
                return null;
            }
            if (res.code != 200) {
                String t = new String(res.data, StandardCharsets.UTF_8);
                log("Fish HTTP " + res.code + ": " + t);
                lastFishError = "HTTP " + res.code + " " + shorten(t);
                return null;
            }
            return res.data;
        } catch (Exception e) {
            log("Fish error: " + e);
            lastFishError = e.toString();
            return null;
        }
    }

    private static void log(String s) {
        org.apache.logging.log4j.LogManager.getLogger(FallotyMod.MODID).warn(s);
    }
}
