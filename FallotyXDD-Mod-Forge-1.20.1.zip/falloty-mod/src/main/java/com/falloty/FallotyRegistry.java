package com.falloty;

import com.falloty.entity.FallotyEntity;
import com.falloty.item.WrappedChocolateItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class FallotyRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FallotyMod.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, FallotyMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FallotyMod.MODID);

    public static final RegistryObject<EntityType<FallotyEntity>> FALLOTY = ENTITIES.register("falloty",
            () -> EntityType.Builder.<FallotyEntity>of(FallotyEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(10).build("falloty"));

    public static final RegistryObject<Item> CHOCOLATE_WRAPPED = ITEMS.register("chocolate_wrapped",
            () -> new WrappedChocolateItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> CHOCOLATE_BAR = ITEMS.register("chocolate_bar",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(5).saturationMod(0.6F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0), 1.0F)
                    .build())));

    public static final RegistryObject<Item> CHOCOLATE_WRAPPER = ITEMS.register("chocolate_wrapper",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("falloty",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.falloty"))
                    .icon(() -> new ItemStack(CHOCOLATE_WRAPPED.get()))
                    .displayItems((params, out) -> {
                        out.accept(CHOCOLATE_WRAPPED.get());
                        out.accept(CHOCOLATE_BAR.get());
                        out.accept(CHOCOLATE_WRAPPER.get());
                    }).build());

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }

    public static boolean isChocolate(ItemStack s) {
        return s.is(CHOCOLATE_WRAPPED.get()) || s.is(CHOCOLATE_BAR.get());
    }
}
