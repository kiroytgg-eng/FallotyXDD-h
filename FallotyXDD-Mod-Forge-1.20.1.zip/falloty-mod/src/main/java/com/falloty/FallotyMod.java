package com.falloty;

import com.falloty.entity.FallotyEntity;
import com.falloty.event.ServerEvents;
import com.falloty.net.FallotyNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.ModLoadingContext;

@Mod(FallotyMod.MODID)
public class FallotyMod {
    public static final String MODID = "falloty";

    public FallotyMod() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        FallotyRegistry.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::attributes);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, FallotyConfig.SPEC, "falloty-common.toml");
        MinecraftForge.EVENT_BUS.register(new ServerEvents());
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(FallotyNetwork::register);
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(FallotyRegistry.FALLOTY.get(), FallotyEntity.createAttributes().build());
    }
}
